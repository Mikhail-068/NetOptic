import io
import csv
from datetime import datetime
from telegram.ext import Application, CommandHandler, MessageHandler, filters, CallbackQueryHandler
from PIL import Image
import numpy as np
import os
import torch
import matplotlib.pyplot as plt
import asyncio
from tensorflow import keras
from ultralytics import YOLO
import cv2
import re
import easyocr
from io import BytesIO
import time

# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
TOKEN = "5804669631:AAGjdkONwz3AtlRsFf-hu-dzgDtVOig3EKo"

# For Bot 1
classes1 = ['Металл', 'Пластик']
classes2 = ['Втулки', 'Леска', 'Ободки']
# ЗАМЕНИТЕ НА ВАШ ФАКТИЧЕСКИЕ ПУТИ К ФАЙЛАМ ВЕСОВ :
model1 = keras.models.load_model('/Users/andrew/Documents/NETOPT/best_model_GA_val_loss_0.0732_val_accuracy_0.9700.h5')
model2 = keras.models.load_model("/Users/andrew/Documents/NETOPT/best_model_GA_val.loss_0.0422_val.acc_0.9896.h5")
model2.load_weights('/Users/andrew/Documents/NETOPT/best_weights_GA_val.loss_0.0422_val.acc_0.9896.h5')

# For Bot 2
reader = easyocr.Reader(['en'])
# ЗАМЕНИТЕ НА ВАШ ФАКТИЧЕСКИЙ ПУТЬ К ФАЙЛУ ВЕСОВ :
model = YOLO('/Users/andrew/Documents/NETOPT/yoloAttrs.pt')

# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


from telegram import InlineKeyboardButton, InlineKeyboardMarkup

# Functions from Bot 1
async def process_image_1(update, context):
    
    # Удаление изображения и кнопок
    await context.bot.delete_message(chat_id=update.callback_query.message.chat_id, message_id=update.callback_query.message.message_id-2)  # удалить изображение
    await context.bot.delete_message(chat_id=update.callback_query.message.chat_id, message_id=update.callback_query.message.message_id-1)  # удалить кнопки
    await context.bot.delete_message(chat_id=update.callback_query.message.chat_id, message_id=update.callback_query.message.message_id)  # удалить кнопки

    img = Image.open("/Users/andrew/Documents/NETOPT/tmp/temp_image_for_processing.jpg")
    user = update.callback_query.from_user
    current_time = datetime.now().strftime('%H:%M')
    

    with open('/Users/andrew/Documents/NETOPT/netopt.csv', 'a', newline='') as file:  
        writer = csv.writer(file)
        writer.writerow([user.id, user.username, user.first_name, current_time])

    # Resize image to target size
    img_resized = img.resize((600, 600))

    # Crop the image
    cropped_image1 = img_resized.crop((40, 160, 560, 410))

    # Resize image for prediction
    img_resized1 = cropped_image1.resize((120, 55))  # resize images if necessary
    img_resized2 = img_resized.resize((128, 182))
    img_np1 = np.array(img_resized1)
    img_np2 = np.array(img_resized2)
    img_np1 = img_np1[np.newaxis, ...]
    img_np2 = img_np2[np.newaxis, ...]  # Add an extra dimension for the batch size

    start_time = time.perf_counter() 

    # Perform inference
    with torch.no_grad():
        prediction1 = model1.predict(img_np1)
        prediction2 = model2.predict(img_np2)

    # Measure how long the inference took
    duration = time.perf_counter() - start_time

    # Determine the predicted classes
    predicted_class1 = classes1[np.argmax(prediction1)]
    predicted_class2 = classes2[np.argmax(prediction2)]

    # Create a new image with the prediction result
    fig, ax = plt.subplots()
    ax.imshow(np.array(img))
    plt.title(f'Predicted classes: {predicted_class1}, {predicted_class2}')
    
    # Save the image to a BytesIO object
    buf = io.BytesIO()
    plt.savefig(buf, format='jpg', dpi=600)
    buf.seek(0)

    # Send photo
    await update.callback_query.message.reply_photo(photo=buf)  # Исправлено здесь

    # Send processing time
    seconds, milliseconds = divmod(duration, 1)
    await update.callback_query.message.reply_text(f"Время обработки {int(seconds):02} сек {int(milliseconds*1000):03} мс")  # Исправлено здесь
    

# Functions from Bot 2
async def process_image_2(update, context):
    await context.bot.delete_message(chat_id=update.callback_query.message.chat_id, message_id=update.callback_query.message.message_id-2)  # удалить изображение
    await context.bot.delete_message(chat_id=update.callback_query.message.chat_id, message_id=update.callback_query.message.message_id-1)  # удалить кнопки
    await context.bot.delete_message(chat_id=update.callback_query.message.chat_id, message_id=update.callback_query.message.message_id)  # удалить кнопки
   
    user = update.callback_query.from_user
    current_time = datetime.now().strftime('%H:%M')
    
    with open('/Users/andrew/Documents/NETOPT/netopt.csv', 'a', newline='') as file:  
        writer = csv.writer(file)
        writer.writerow([user.id, user.username, user.first_name, current_time])

    img_path = "/Users/andrew/Documents/NETOPT/tmp/temp_image_for_processing.jpg"
    #img.save(img_path)
    start_time = time.perf_counter() 
    crop_one_image_and_save(img_path, "/Users/andrew/Documents/NETOPT/tmp")
    duration = time.perf_counter() - start_time

     
    with open("/Users/andrew/Documents/NETOPT/tmp/predicted_image.png", "rb") as f:
        await update.callback_query.message.reply_photo(photo=f)
   
         # Send processing time
        seconds, milliseconds = divmod(duration, 1)
        await update.callback_query.message.reply_text(f"Время обработки {int(seconds):02} сек {int(milliseconds*1000):03} мс")  # Исправлено здесь
        
def regex_attrs(s):
    s = s.replace('-', ' ').replace('  ', ' ')
    rez = re.search(r'(\d\d\d)(\s\d\d).{0,2}(\d\d\s)(.*)', s[::-1])
    if rez:
        temple_length = rez[1][::-1]
        nose_bridge = rez[2][::-1]
        lens_width = rez[3][::-1]
        model_name = rez[4][::-1]
        frame_width = str(int(lens_width)*2 + int(nose_bridge))
        return temple_length, nose_bridge, lens_width, frame_width, model_name
    else:
        return None, None, None, None, None

def get_bboxes(prediction, W, H):
    for i in prediction:
        bboxes = i.boxes.cpu().xyxyn.numpy().squeeze()
        break
    y1 = int(float(bboxes[0]) * W) - 30
    x1 = int(float(bboxes[1]) * H) - 30
    y2 = int(float(bboxes[2]) * W) + 30
    x2 = int(float(bboxes[3]) * H) + 30
    return x1, y1, x2, y2

def find_text(crop_img):
    if crop_img.size == 0:
        print("The cropped image is empty!")
        return None, None, None, None, None, None
    text = reader.readtext(crop_img, detail=0)
    text = ' '.join(j for j in text)
    temple_length, nose_bridge, lens_width, frame_width, model_name = regex_attrs(text)
    return text, model_name, lens_width, nose_bridge, temple_length, frame_width

def crop_one_image_and_save(image_path, output_folder):
    img = cv2.imread(image_path)
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    H = img.shape[0]
    W = img.shape[1]
    pred = model.predict(image_path, max_det=1, verbose=False)
    x1, y1, x2, y2 = get_bboxes(pred, W, H)
    crop_img = img[x1:x2, y1:y2, :]
    text, model_name, lens_width, nose_bridge, temple_length, frame_width = find_text(crop_img)
    
    plt.figure(figsize=(7, 4))
    
    plt.subplot(121)
    plt.imshow(crop_img)
    plt.axis('off')
    
    plt.subplot(122)
    plt.text(0, 0.5, 'Модель: {}\nШирина линзы: {}\nПереносица: {}\nДлина дужки: {}\nШирина оправы: {}, \nРаспознанный текст:\n{}'
             ''.format(model_name, lens_width, nose_bridge, temple_length, frame_width, text), size='large')
    plt.axis('off')
    
    output_folder = '/Users/andrew/Documents/NETOPT/tmp'
    output_filename = os.path.join(output_folder, 'predicted_image.png') 
    plt.savefig(output_filename)
    plt.close()
       

# New combined functions and handlers
async def start(update, context):
    await update.message.reply_text('Отправьте изображение оправы или дужки с артикулом')

async def ask_for_action(update, context):
    await update.message.reply_text('Изображение получено')
    keyboard = [
        [InlineKeyboardButton("Определить оправу", callback_data='bot_1'),
         InlineKeyboardButton("Распознать артикул", callback_data='bot_2')]
    ]

    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text('Выберите действие:', reply_markup=reply_markup)

async def button(update, context):
    query = update.callback_query
    await query.answer()  # Добавлено "await"
    if query.data == "bot_1":
        await process_image_1(update, context)
    elif query.data == "bot_2":
        await process_image_2(update, context)

        
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, filters

async def handle_image(update, context):
    file = await context.bot.get_file(update.message.photo[-1].file_id)
    img = Image.open(BytesIO(await file.download_as_bytearray()))
    img_path = "/Users/andrew/Documents/NETOPT/tmp/temp_image_for_processing.jpg"
    img.save(img_path)  # Save the image temporarily
    await ask_for_action(update, context)

def main():
    application = Application.builder().token(TOKEN).build()
    print('Бот запущен...')
    application.add_handler(CommandHandler("start", start))
    application.add_handler(MessageHandler(filters.PHOTO, handle_image))
    application.add_handler(CallbackQueryHandler(button))
    application.run_polling()

if __name__ == "__main__":
    main()